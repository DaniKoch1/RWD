$("#exampleButtonId").on("click", function() {
    var attributeContent = $("#imageId").attr("src");
    $(this).text(attributeContent);
});
