// Call to function
$("#orangeBoxId").animate({left: "+=200"},"slow",function() {squareMovement(this)});

// Declaration of function
function squareMovement(IdRef) {
    $(IdRef).animate({top: "+=100"}).animate({left: "+=100"}).animate({top: "-=100"}).animate({left: "-=100"}, function(){squareMovement(IdRef);});
}
